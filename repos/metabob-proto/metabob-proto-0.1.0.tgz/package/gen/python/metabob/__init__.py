"""
Metabob Protocol Buffer Generated Code

This package contains auto-generated Python code from Protocol Buffer definitions.
Do not edit these files manually.
"""

__version__ = "0.1.0"
