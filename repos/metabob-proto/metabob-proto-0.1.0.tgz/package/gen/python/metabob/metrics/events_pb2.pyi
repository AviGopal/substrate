import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MetricEvent(_message.Message):
    __slots__ = ()
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PROBLEM_COUNT_FIELD_NUMBER: _ClassVar[int]
    PROBLEM_TYPES_FIELD_NUMBER: _ClassVar[int]
    PROBLEM_SEVERITIES_FIELD_NUMBER: _ClassVar[int]
    FILE_PATH_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    PROBLEM_ID_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    event_type: str
    timestamp: _timestamp_pb2.Timestamp
    org_id: str
    project_id: str
    user_id: str
    session_id: str
    problem_count: int
    problem_types: _containers.RepeatedScalarFieldContainer[str]
    problem_severities: _containers.RepeatedScalarFieldContainer[str]
    file_path: str
    interaction_type: str
    problem_id: str
    def __init__(self, event_id: _Optional[str] = ..., event_type: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., org_id: _Optional[str] = ..., project_id: _Optional[str] = ..., user_id: _Optional[str] = ..., session_id: _Optional[str] = ..., problem_count: _Optional[int] = ..., problem_types: _Optional[_Iterable[str]] = ..., problem_severities: _Optional[_Iterable[str]] = ..., file_path: _Optional[str] = ..., interaction_type: _Optional[str] = ..., problem_id: _Optional[str] = ...) -> None: ...

class DailyMetrics(_message.Message):
    __slots__ = ()
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PROBLEMS_FIELD_NUMBER: _ClassVar[int]
    PROBLEMS_BY_SEVERITY_FIELD_NUMBER: _ClassVar[int]
    PROBLEMS_BY_TYPE_FIELD_NUMBER: _ClassVar[int]
    PROBLEMS_ENDORSED_FIELD_NUMBER: _ClassVar[int]
    PROBLEMS_DISCARDED_FIELD_NUMBER: _ClassVar[int]
    PROBLEMS_FIXED_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FILES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIX_GENERATIONS_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    project_id: str
    date: str
    total_problems: int
    problems_by_severity: _containers.RepeatedCompositeFieldContainer[CategoryCount]
    problems_by_type: _containers.RepeatedCompositeFieldContainer[CategoryCount]
    problems_endorsed: int
    problems_discarded: int
    problems_fixed: int
    total_sessions: int
    total_files: int
    total_fix_generations: int
    def __init__(self, org_id: _Optional[str] = ..., project_id: _Optional[str] = ..., date: _Optional[str] = ..., total_problems: _Optional[int] = ..., problems_by_severity: _Optional[_Iterable[_Union[CategoryCount, _Mapping]]] = ..., problems_by_type: _Optional[_Iterable[_Union[CategoryCount, _Mapping]]] = ..., problems_endorsed: _Optional[int] = ..., problems_discarded: _Optional[int] = ..., problems_fixed: _Optional[int] = ..., total_sessions: _Optional[int] = ..., total_files: _Optional[int] = ..., total_fix_generations: _Optional[int] = ...) -> None: ...

class CategoryCount(_message.Message):
    __slots__ = ()
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    category: str
    count: int
    def __init__(self, category: _Optional[str] = ..., count: _Optional[int] = ...) -> None: ...

class SchemaVersion(_message.Message):
    __slots__ = ()
    class MetadataEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    MIGRATION_SCRIPT_FIELD_NUMBER: _ClassVar[int]
    APPLIED_AT_FIELD_NUMBER: _ClassVar[int]
    APPLIED_BY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    version: int
    description: str
    migration_script: str
    applied_at: _timestamp_pb2.Timestamp
    applied_by: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, version: _Optional[int] = ..., description: _Optional[str] = ..., migration_script: _Optional[str] = ..., applied_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., applied_by: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...
