import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConsumerProfile(_message.Message):
    __slots__ = ()
    class SelectionHistoryEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    class SuccessRateByCategoryEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: float
        def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    CONSUMER_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_LANGUAGE_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_FRAMEWORK_FIELD_NUMBER: _ClassVar[int]
    TECH_STACK_FIELD_NUMBER: _ClassVar[int]
    SELECTION_HISTORY_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_RATE_BY_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    PREFERS_SPEED_FIELD_NUMBER: _ClassVar[int]
    PREFERS_COST_FIELD_NUMBER: _ClassVar[int]
    PREFERS_QUALITY_FIELD_NUMBER: _ClassVar[int]
    TOTAL_IMPRESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELECTIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SUCCESSES_FIELD_NUMBER: _ClassVar[int]
    OVERALL_CTR_FIELD_NUMBER: _ClassVar[int]
    OVERALL_CONVERSION_RATE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    consumer_id: str
    org_id: str
    project_id: str
    primary_language: str
    primary_framework: str
    tech_stack: _containers.RepeatedScalarFieldContainer[str]
    selection_history: _containers.ScalarMap[str, int]
    success_rate_by_category: _containers.ScalarMap[str, float]
    prefers_speed: float
    prefers_cost: float
    prefers_quality: float
    total_impressions: int
    total_selections: int
    total_successes: int
    overall_ctr: float
    overall_conversion_rate: float
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, consumer_id: _Optional[str] = ..., org_id: _Optional[str] = ..., project_id: _Optional[str] = ..., primary_language: _Optional[str] = ..., primary_framework: _Optional[str] = ..., tech_stack: _Optional[_Iterable[str]] = ..., selection_history: _Optional[_Mapping[str, int]] = ..., success_rate_by_category: _Optional[_Mapping[str, float]] = ..., prefers_speed: _Optional[float] = ..., prefers_cost: _Optional[float] = ..., prefers_quality: _Optional[float] = ..., total_impressions: _Optional[int] = ..., total_selections: _Optional[int] = ..., total_successes: _Optional[int] = ..., overall_ctr: _Optional[float] = ..., overall_conversion_rate: _Optional[float] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ActivityImpression(_message.Message):
    __slots__ = ()
    IMPRESSION_ID_FIELD_NUMBER: _ClassVar[int]
    CONSUMER_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
    INTENT_FIELD_NUMBER: _ClassVar[int]
    RANK_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SHOWN_FIELD_NUMBER: _ClassVar[int]
    PREDICTED_CTR_FIELD_NUMBER: _ClassVar[int]
    PREDICTED_CONVERSION_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_VALUE_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    TREATMENT_GROUP_FIELD_NUMBER: _ClassVar[int]
    WAS_SELECTED_FIELD_NUMBER: _ClassVar[int]
    SELECTION_TIME_MS_FIELD_NUMBER: _ClassVar[int]
    SHOWN_AT_FIELD_NUMBER: _ClassVar[int]
    SELECTED_AT_FIELD_NUMBER: _ClassVar[int]
    impression_id: str
    consumer_id: str
    session_id: str
    variant_id: str
    activity_id: str
    intent: str
    rank: int
    total_shown: int
    predicted_ctr: float
    predicted_conversion: float
    expected_value: float
    experiment_id: str
    treatment_group: str
    was_selected: bool
    selection_time_ms: int
    shown_at: _timestamp_pb2.Timestamp
    selected_at: _timestamp_pb2.Timestamp
    def __init__(self, impression_id: _Optional[str] = ..., consumer_id: _Optional[str] = ..., session_id: _Optional[str] = ..., variant_id: _Optional[str] = ..., activity_id: _Optional[str] = ..., intent: _Optional[str] = ..., rank: _Optional[int] = ..., total_shown: _Optional[int] = ..., predicted_ctr: _Optional[float] = ..., predicted_conversion: _Optional[float] = ..., expected_value: _Optional[float] = ..., experiment_id: _Optional[str] = ..., treatment_group: _Optional[str] = ..., was_selected: _Optional[bool] = ..., selection_time_ms: _Optional[int] = ..., shown_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., selected_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
