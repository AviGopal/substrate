"""Activity system protocol buffer types"""

from .variant_pb2 import (
    ActivityVariant,
    TaskStep,
    TaskPrompt,
    TaskValidation,
    TaskRetry,
    TaskMetrics,
    TaskComplexity,
    VariantPerformanceMetrics,
    CompositionConfig,
    LearningConfig,
    ExpectedOutcome,
)
from .execution_pb2 import (
    ExecutionConfig,
    ContextRequirement,
    IntegrationConfig,
    HooksConfig,
    TaskExecutionConfig,
    ImpulseReference,
)
from .optimization_pb2 import (
    OptimizationConfig,
    ThompsonSamplingConfig,
    TrafficAllocationConfig,
)
from .admin_pb2 import (
    AdminConfig,
    AuthoringMetadata,
    ValidationRules,
    DocumentationMetadata,
    DeploymentConfig,
)

__all__ = [
    # Variant types
    "ActivityVariant",
    "TaskStep",
    "TaskPrompt",
    "TaskValidation",
    "TaskRetry",
    "TaskMetrics",
    "TaskComplexity",
    "VariantPerformanceMetrics",
    "CompositionConfig",
    "LearningConfig",
    "ExpectedOutcome",
    # Execution types
    "ExecutionConfig",
    "ContextRequirement",
    "IntegrationConfig",
    "HooksConfig",
    "TaskExecutionConfig",
    "ImpulseReference",
    # Optimization types
    "OptimizationConfig",
    "ThompsonSamplingConfig",
    "TrafficAllocationConfig",
    # Admin types
    "AdminConfig",
    "AuthoringMetadata",
    "ValidationRules",
    "DocumentationMetadata",
    "DeploymentConfig",
]
