from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import any_pb2 as _any_pb2
from metabob.common import types_pb2 as _types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExecutionConfig(_message.Message):
    __slots__ = ()
    class RepositoriesEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: RepositoryMapping
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[RepositoryMapping, _Mapping]] = ...) -> None: ...
    CONTEXT_REQUIREMENTS_FIELD_NUMBER: _ClassVar[int]
    INTEGRATION_FIELD_NUMBER: _ClassVar[int]
    METABOB_FIELD_NUMBER: _ClassVar[int]
    HOOKS_FIELD_NUMBER: _ClassVar[int]
    REPOSITORIES_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_NEGOTIATION_FIELD_NUMBER: _ClassVar[int]
    DISCOVERY_PHASE_FIELD_NUMBER: _ClassVar[int]
    MEMORY_MANAGEMENT_FIELD_NUMBER: _ClassVar[int]
    context_requirements: _containers.RepeatedCompositeFieldContainer[ContextRequirement]
    integration: IntegrationConfig
    metabob: MetabobIntegrationConfig
    hooks: HooksConfig
    repositories: _containers.MessageMap[str, RepositoryMapping]
    context_negotiation: ContextNegotiation
    discovery_phase: DiscoveryPhase
    memory_management: MemoryManagement
    def __init__(self, context_requirements: _Optional[_Iterable[_Union[ContextRequirement, _Mapping]]] = ..., integration: _Optional[_Union[IntegrationConfig, _Mapping]] = ..., metabob: _Optional[_Union[MetabobIntegrationConfig, _Mapping]] = ..., hooks: _Optional[_Union[HooksConfig, _Mapping]] = ..., repositories: _Optional[_Mapping[str, RepositoryMapping]] = ..., context_negotiation: _Optional[_Union[ContextNegotiation, _Mapping]] = ..., discovery_phase: _Optional[_Union[DiscoveryPhase, _Mapping]] = ..., memory_management: _Optional[_Union[MemoryManagement, _Mapping]] = ...) -> None: ...

class ContextRequirement(_message.Message):
    __slots__ = ()
    KEY_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    IMPULSE_TYPES_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    BUDGET_RANGE_FIELD_NUMBER: _ClassVar[int]
    key: str
    hint: str
    impulse_types: _containers.RepeatedScalarFieldContainer[str]
    required: bool
    budget_range: TokenBudgetRange
    def __init__(self, key: _Optional[str] = ..., hint: _Optional[str] = ..., impulse_types: _Optional[_Iterable[str]] = ..., required: _Optional[bool] = ..., budget_range: _Optional[_Union[TokenBudgetRange, _Mapping]] = ...) -> None: ...

class TokenBudgetRange(_message.Message):
    __slots__ = ()
    MIN_TOKENS_FIELD_NUMBER: _ClassVar[int]
    MAX_TOKENS_FIELD_NUMBER: _ClassVar[int]
    min_tokens: int
    max_tokens: int
    def __init__(self, min_tokens: _Optional[int] = ..., max_tokens: _Optional[int] = ...) -> None: ...

class ContextNegotiation(_message.Message):
    __slots__ = ()
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    MAX_ROUNDS_FIELD_NUMBER: _ClassVar[int]
    prompt: str
    max_rounds: int
    def __init__(self, prompt: _Optional[str] = ..., max_rounds: _Optional[int] = ...) -> None: ...

class IntegrationConfig(_message.Message):
    __slots__ = ()
    PRE_CHECKS_FIELD_NUMBER: _ClassVar[int]
    POST_CHECKS_FIELD_NUMBER: _ClassVar[int]
    QUALITY_GATES_FIELD_NUMBER: _ClassVar[int]
    pre_checks: _containers.RepeatedScalarFieldContainer[str]
    post_checks: _containers.RepeatedScalarFieldContainer[str]
    quality_gates: _containers.RepeatedCompositeFieldContainer[QualityGate]
    def __init__(self, pre_checks: _Optional[_Iterable[str]] = ..., post_checks: _Optional[_Iterable[str]] = ..., quality_gates: _Optional[_Iterable[_Union[QualityGate, _Mapping]]] = ...) -> None: ...

class QualityGate(_message.Message):
    __slots__ = ()
    NAME_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    name: str
    command: str
    required: bool
    def __init__(self, name: _Optional[str] = ..., command: _Optional[str] = ..., required: _Optional[bool] = ...) -> None: ...

class MetabobIntegrationConfig(_message.Message):
    __slots__ = ()
    class AnnotationStrategy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        ANNOTATION_STRATEGY_UNSPECIFIED: _ClassVar[MetabobIntegrationConfig.AnnotationStrategy]
        ANNOTATION_STRATEGY_ALL: _ClassVar[MetabobIntegrationConfig.AnnotationStrategy]
        ANNOTATION_STRATEGY_KEY_COMPONENTS: _ClassVar[MetabobIntegrationConfig.AnnotationStrategy]
        ANNOTATION_STRATEGY_FAILURES_ONLY: _ClassVar[MetabobIntegrationConfig.AnnotationStrategy]
    ANNOTATION_STRATEGY_UNSPECIFIED: MetabobIntegrationConfig.AnnotationStrategy
    ANNOTATION_STRATEGY_ALL: MetabobIntegrationConfig.AnnotationStrategy
    ANNOTATION_STRATEGY_KEY_COMPONENTS: MetabobIntegrationConfig.AnnotationStrategy
    ANNOTATION_STRATEGY_FAILURES_ONLY: MetabobIntegrationConfig.AnnotationStrategy
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    LEARNING_MODE_FIELD_NUMBER: _ClassVar[int]
    TARGET_CONTEXT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    ANNOTATION_STRATEGY_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    learning_mode: bool
    target_context_tokens: int
    annotation_strategy: MetabobIntegrationConfig.AnnotationStrategy
    def __init__(self, enabled: _Optional[bool] = ..., learning_mode: _Optional[bool] = ..., target_context_tokens: _Optional[int] = ..., annotation_strategy: _Optional[_Union[MetabobIntegrationConfig.AnnotationStrategy, str]] = ...) -> None: ...

class HooksConfig(_message.Message):
    __slots__ = ()
    PRE_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    PRE_TASK_FIELD_NUMBER: _ClassVar[int]
    POST_TASK_FIELD_NUMBER: _ClassVar[int]
    POST_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    ON_ERROR_FIELD_NUMBER: _ClassVar[int]
    pre_activity: PreActivityHook
    pre_task: PreTaskHook
    post_task: PostTaskHook
    post_activity: PostActivityHook
    on_error: ErrorHook
    def __init__(self, pre_activity: _Optional[_Union[PreActivityHook, _Mapping]] = ..., pre_task: _Optional[_Union[PreTaskHook, _Mapping]] = ..., post_task: _Optional[_Union[PostTaskHook, _Mapping]] = ..., post_activity: _Optional[_Union[PostActivityHook, _Mapping]] = ..., on_error: _Optional[_Union[ErrorHook, _Mapping]] = ...) -> None: ...

class PreActivityHook(_message.Message):
    __slots__ = ()
    class EnvironmentEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    WORKING_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    LOAD_IMPULSES_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    working_directory: WorkingDirectoryConfig
    load_impulses: _containers.RepeatedScalarFieldContainer[str]
    environment: _containers.ScalarMap[str, str]
    commands: _containers.RepeatedCompositeFieldContainer[ValidationCommand]
    def __init__(self, working_directory: _Optional[_Union[WorkingDirectoryConfig, _Mapping]] = ..., load_impulses: _Optional[_Iterable[str]] = ..., environment: _Optional[_Mapping[str, str]] = ..., commands: _Optional[_Iterable[_Union[ValidationCommand, _Mapping]]] = ...) -> None: ...

class WorkingDirectoryConfig(_message.Message):
    __slots__ = ()
    CURRENT_FIELD_NUMBER: _ClassVar[int]
    TEMPORARY_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_FIELD_NUMBER: _ClassVar[int]
    current: CurrentDirectory
    temporary: TemporaryDirectory
    custom: CustomDirectory
    def __init__(self, current: _Optional[_Union[CurrentDirectory, _Mapping]] = ..., temporary: _Optional[_Union[TemporaryDirectory, _Mapping]] = ..., custom: _Optional[_Union[CustomDirectory, _Mapping]] = ...) -> None: ...

class CurrentDirectory(_message.Message):
    __slots__ = ()
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str
    def __init__(self, path: _Optional[str] = ...) -> None: ...

class TemporaryDirectory(_message.Message):
    __slots__ = ()
    class CleanupPolicy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        CLEANUP_POLICY_UNSPECIFIED: _ClassVar[TemporaryDirectory.CleanupPolicy]
        CLEANUP_POLICY_ALWAYS: _ClassVar[TemporaryDirectory.CleanupPolicy]
        CLEANUP_POLICY_ON_SUCCESS: _ClassVar[TemporaryDirectory.CleanupPolicy]
        CLEANUP_POLICY_ON_ERROR: _ClassVar[TemporaryDirectory.CleanupPolicy]
        CLEANUP_POLICY_NEVER: _ClassVar[TemporaryDirectory.CleanupPolicy]
    CLEANUP_POLICY_UNSPECIFIED: TemporaryDirectory.CleanupPolicy
    CLEANUP_POLICY_ALWAYS: TemporaryDirectory.CleanupPolicy
    CLEANUP_POLICY_ON_SUCCESS: TemporaryDirectory.CleanupPolicy
    CLEANUP_POLICY_ON_ERROR: TemporaryDirectory.CleanupPolicy
    CLEANUP_POLICY_NEVER: TemporaryDirectory.CleanupPolicy
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    prefix: str
    cleanup: TemporaryDirectory.CleanupPolicy
    def __init__(self, prefix: _Optional[str] = ..., cleanup: _Optional[_Union[TemporaryDirectory.CleanupPolicy, str]] = ...) -> None: ...

class CustomDirectory(_message.Message):
    __slots__ = ()
    PATH_FIELD_NUMBER: _ClassVar[int]
    CREATE_IF_MISSING_FIELD_NUMBER: _ClassVar[int]
    path: str
    create_if_missing: bool
    def __init__(self, path: _Optional[str] = ..., create_if_missing: _Optional[bool] = ...) -> None: ...

class PreTaskHook(_message.Message):
    __slots__ = ()
    LOAD_TASK_IMPULSES_FIELD_NUMBER: _ClassVar[int]
    VALIDATE_TOOLS_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    load_task_impulses: _containers.RepeatedScalarFieldContainer[str]
    validate_tools: bool
    commands: _containers.RepeatedCompositeFieldContainer[ValidationCommand]
    def __init__(self, load_task_impulses: _Optional[_Iterable[str]] = ..., validate_tools: _Optional[bool] = ..., commands: _Optional[_Iterable[_Union[ValidationCommand, _Mapping]]] = ...) -> None: ...

class PostTaskHook(_message.Message):
    __slots__ = ()
    UNLOAD_LOW_PRIORITY_IMPULSES_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    unload_low_priority_impulses: bool
    capture_outputs: _containers.RepeatedCompositeFieldContainer[OutputCapture]
    commands: _containers.RepeatedCompositeFieldContainer[ValidationCommand]
    def __init__(self, unload_low_priority_impulses: _Optional[bool] = ..., capture_outputs: _Optional[_Iterable[_Union[OutputCapture, _Mapping]]] = ..., commands: _Optional[_Iterable[_Union[ValidationCommand, _Mapping]]] = ...) -> None: ...

class OutputCapture(_message.Message):
    __slots__ = ()
    NAME_FIELD_NUMBER: _ClassVar[int]
    PATTERN_FIELD_NUMBER: _ClassVar[int]
    CREATE_IMPULSE_FIELD_NUMBER: _ClassVar[int]
    IMPULSE_BUDGET_FIELD_NUMBER: _ClassVar[int]
    name: str
    pattern: str
    create_impulse: bool
    impulse_budget: int
    def __init__(self, name: _Optional[str] = ..., pattern: _Optional[str] = ..., create_impulse: _Optional[bool] = ..., impulse_budget: _Optional[int] = ...) -> None: ...

class PostActivityHook(_message.Message):
    __slots__ = ()
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    EXTRACT_FILES_FIELD_NUMBER: _ClassVar[int]
    PERSIST_IMPULSES_FIELD_NUMBER: _ClassVar[int]
    CREATE_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    cleanup: bool
    extract_files: _containers.RepeatedScalarFieldContainer[str]
    persist_impulses: bool
    create_summary: bool
    commands: _containers.RepeatedCompositeFieldContainer[ValidationCommand]
    def __init__(self, cleanup: _Optional[bool] = ..., extract_files: _Optional[_Iterable[str]] = ..., persist_impulses: _Optional[bool] = ..., create_summary: _Optional[bool] = ..., commands: _Optional[_Iterable[_Union[ValidationCommand, _Mapping]]] = ...) -> None: ...

class ErrorHook(_message.Message):
    __slots__ = ()
    CAPTURE_ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_LOGS_FIELD_NUMBER: _ClassVar[int]
    CREATE_DIAGNOSTIC_IMPULSE_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    capture_environment: bool
    capture_logs: LogCapture
    create_diagnostic_impulse: bool
    cleanup: bool
    commands: _containers.RepeatedCompositeFieldContainer[ValidationCommand]
    def __init__(self, capture_environment: _Optional[bool] = ..., capture_logs: _Optional[_Union[LogCapture, _Mapping]] = ..., create_diagnostic_impulse: _Optional[bool] = ..., cleanup: _Optional[bool] = ..., commands: _Optional[_Iterable[_Union[ValidationCommand, _Mapping]]] = ...) -> None: ...

class LogCapture(_message.Message):
    __slots__ = ()
    TAIL_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_TRANSCRIPT_FIELD_NUMBER: _ClassVar[int]
    LOG_FILES_FIELD_NUMBER: _ClassVar[int]
    tail: int
    include_transcript: bool
    log_files: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, tail: _Optional[int] = ..., include_transcript: _Optional[bool] = ..., log_files: _Optional[_Iterable[str]] = ...) -> None: ...

class ValidationCommand(_message.Message):
    __slots__ = ()
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_EXIT_CODE_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    command: str
    expected_exit_code: int
    timeout_seconds: int
    required: bool
    description: str
    def __init__(self, command: _Optional[str] = ..., expected_exit_code: _Optional[int] = ..., timeout_seconds: _Optional[int] = ..., required: _Optional[bool] = ..., description: _Optional[str] = ...) -> None: ...

class RepositoryMapping(_message.Message):
    __slots__ = ()
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_FIELD_NUMBER: _ClassVar[int]
    WORKING_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    name: str
    connection: str
    working_directory: str
    description: str
    def __init__(self, name: _Optional[str] = ..., connection: _Optional[str] = ..., working_directory: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class DiscoveryPhase(_message.Message):
    __slots__ = ()
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TEMPLATES_FIELD_NUMBER: _ClassVar[int]
    SEARCH_CODEBASE_FIELD_NUMBER: _ClassVar[int]
    MIN_SIMILARITY_CHECKS_FIELD_NUMBER: _ClassVar[int]
    SIMILARITY_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    MAX_DISCOVERY_TIME_SECONDS_FIELD_NUMBER: _ClassVar[int]
    required: bool
    search_templates: bool
    search_codebase: bool
    min_similarity_checks: int
    similarity_threshold: int
    max_discovery_time_seconds: int
    def __init__(self, required: _Optional[bool] = ..., search_templates: _Optional[bool] = ..., search_codebase: _Optional[bool] = ..., min_similarity_checks: _Optional[int] = ..., similarity_threshold: _Optional[int] = ..., max_discovery_time_seconds: _Optional[int] = ...) -> None: ...

class MemoryManagement(_message.Message):
    __slots__ = ()
    class Strategy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        STRATEGY_UNSPECIFIED: _ClassVar[MemoryManagement.Strategy]
        STRATEGY_CONSERVATIVE: _ClassVar[MemoryManagement.Strategy]
        STRATEGY_BALANCED: _ClassVar[MemoryManagement.Strategy]
        STRATEGY_AGGRESSIVE: _ClassVar[MemoryManagement.Strategy]
    STRATEGY_UNSPECIFIED: MemoryManagement.Strategy
    STRATEGY_CONSERVATIVE: MemoryManagement.Strategy
    STRATEGY_BALANCED: MemoryManagement.Strategy
    STRATEGY_AGGRESSIVE: MemoryManagement.Strategy
    STRATEGY_FIELD_NUMBER: _ClassVar[int]
    UNLOAD_LOW_PRIORITY_FIELD_NUMBER: _ClassVar[int]
    KEEP_HIGH_PRIORITY_FIELD_NUMBER: _ClassVar[int]
    OPTIMIZATION_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    MAX_TOKEN_BUDGET_FIELD_NUMBER: _ClassVar[int]
    strategy: MemoryManagement.Strategy
    unload_low_priority: bool
    keep_high_priority: bool
    optimization_threshold: float
    max_token_budget: int
    def __init__(self, strategy: _Optional[_Union[MemoryManagement.Strategy, str]] = ..., unload_low_priority: _Optional[bool] = ..., keep_high_priority: _Optional[bool] = ..., optimization_threshold: _Optional[float] = ..., max_token_budget: _Optional[int] = ...) -> None: ...

class TaskExecutionConfig(_message.Message):
    __slots__ = ()
    EXECUTION_TARGET_FIELD_NUMBER: _ClassVar[int]
    IMPULSE_ADJUSTMENT_FIELD_NUMBER: _ClassVar[int]
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    IMPULSE_REFERENCES_FIELD_NUMBER: _ClassVar[int]
    execution_target: TaskExecutionTarget
    impulse_adjustment: ImpulseAdjustment
    tools: TaskTools
    impulse_references: _containers.RepeatedCompositeFieldContainer[ImpulseReference]
    def __init__(self, execution_target: _Optional[_Union[TaskExecutionTarget, _Mapping]] = ..., impulse_adjustment: _Optional[_Union[ImpulseAdjustment, _Mapping]] = ..., tools: _Optional[_Union[TaskTools, _Mapping]] = ..., impulse_references: _Optional[_Iterable[_Union[ImpulseReference, _Mapping]]] = ...) -> None: ...

class TaskExecutionTarget(_message.Message):
    __slots__ = ()
    LOCAL_FIELD_NUMBER: _ClassVar[int]
    REMOTE_FIELD_NUMBER: _ClassVar[int]
    local: LocalExecution
    remote: RemoteExecution
    def __init__(self, local: _Optional[_Union[LocalExecution, _Mapping]] = ..., remote: _Optional[_Union[RemoteExecution, _Mapping]] = ...) -> None: ...

class LocalExecution(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RemoteExecution(_message.Message):
    __slots__ = ()
    CONNECTION_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    WORKING_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    SHARE_IMPULSES_FIELD_NUMBER: _ClassVar[int]
    SYNC_SESSION_STATE_FIELD_NUMBER: _ClassVar[int]
    SYNC_ACTIVITY_STATE_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    connection: str
    repository: str
    working_directory: str
    share_impulses: bool
    sync_session_state: bool
    sync_activity_state: bool
    timeout_seconds: int
    def __init__(self, connection: _Optional[str] = ..., repository: _Optional[str] = ..., working_directory: _Optional[str] = ..., share_impulses: _Optional[bool] = ..., sync_session_state: _Optional[bool] = ..., sync_activity_state: _Optional[bool] = ..., timeout_seconds: _Optional[int] = ...) -> None: ...

class ImpulseAdjustment(_message.Message):
    __slots__ = ()
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    BEFORE_EXECUTION_FIELD_NUMBER: _ClassVar[int]
    TARGET_TOKEN_BUDGET_FIELD_NUMBER: _ClassVar[int]
    prompt: str
    before_execution: bool
    target_token_budget: int
    def __init__(self, prompt: _Optional[str] = ..., before_execution: _Optional[bool] = ..., target_token_budget: _Optional[int] = ...) -> None: ...

class TaskTools(_message.Message):
    __slots__ = ()
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    OPTIONAL_FIELD_NUMBER: _ClassVar[int]
    DISABLED_FIELD_NUMBER: _ClassVar[int]
    required: _containers.RepeatedScalarFieldContainer[str]
    optional: _containers.RepeatedScalarFieldContainer[str]
    disabled: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, required: _Optional[_Iterable[str]] = ..., optional: _Optional[_Iterable[str]] = ..., disabled: _Optional[_Iterable[str]] = ...) -> None: ...

class ImpulseReference(_message.Message):
    __slots__ = ()
    class ImpulsePriority(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        IMPULSE_PRIORITY_UNSPECIFIED: _ClassVar[ImpulseReference.ImpulsePriority]
        IMPULSE_PRIORITY_LOW: _ClassVar[ImpulseReference.ImpulsePriority]
        IMPULSE_PRIORITY_MEDIUM: _ClassVar[ImpulseReference.ImpulsePriority]
        IMPULSE_PRIORITY_HIGH: _ClassVar[ImpulseReference.ImpulsePriority]
        IMPULSE_PRIORITY_CRITICAL: _ClassVar[ImpulseReference.ImpulsePriority]
    IMPULSE_PRIORITY_UNSPECIFIED: ImpulseReference.ImpulsePriority
    IMPULSE_PRIORITY_LOW: ImpulseReference.ImpulsePriority
    IMPULSE_PRIORITY_MEDIUM: ImpulseReference.ImpulsePriority
    IMPULSE_PRIORITY_HIGH: ImpulseReference.ImpulsePriority
    IMPULSE_PRIORITY_CRITICAL: ImpulseReference.ImpulsePriority
    IMPULSE_ID_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    MIN_TOKENS_FIELD_NUMBER: _ClassVar[int]
    MAX_TOKENS_FIELD_NUMBER: _ClassVar[int]
    impulse_id: str
    priority: ImpulseReference.ImpulsePriority
    required: bool
    min_tokens: int
    max_tokens: int
    def __init__(self, impulse_id: _Optional[str] = ..., priority: _Optional[_Union[ImpulseReference.ImpulsePriority, str]] = ..., required: _Optional[bool] = ..., min_tokens: _Optional[int] = ..., max_tokens: _Optional[int] = ...) -> None: ...
