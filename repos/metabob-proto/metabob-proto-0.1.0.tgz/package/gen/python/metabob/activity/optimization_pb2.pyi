import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class OptimizationConfig(_message.Message):
    __slots__ = ()
    THOMPSON_SAMPLING_FIELD_NUMBER: _ClassVar[int]
    TRAFFIC_ALLOCATION_FIELD_NUMBER: _ClassVar[int]
    PERFORMANCE_THRESHOLDS_FIELD_NUMBER: _ClassVar[int]
    AUTO_PROMOTION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    thompson_sampling: ThompsonSamplingConfig
    traffic_allocation: TrafficAllocationConfig
    performance_thresholds: PerformanceThresholds
    auto_promotion: AutoPromotionConfig
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, thompson_sampling: _Optional[_Union[ThompsonSamplingConfig, _Mapping]] = ..., traffic_allocation: _Optional[_Union[TrafficAllocationConfig, _Mapping]] = ..., performance_thresholds: _Optional[_Union[PerformanceThresholds, _Mapping]] = ..., auto_promotion: _Optional[_Union[AutoPromotionConfig, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ThompsonSamplingConfig(_message.Message):
    __slots__ = ()
    INITIAL_ALPHA_FIELD_NUMBER: _ClassVar[int]
    INITIAL_BETA_FIELD_NUMBER: _ClassVar[int]
    EXPLORATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    MIN_IMPRESSIONS_FIELD_NUMBER: _ClassVar[int]
    MIN_IMPRESSIONS_NEW_VARIANT_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    initial_alpha: float
    initial_beta: float
    exploration_weight: float
    min_impressions: int
    min_impressions_new_variant: int
    confidence_level: float
    def __init__(self, initial_alpha: _Optional[float] = ..., initial_beta: _Optional[float] = ..., exploration_weight: _Optional[float] = ..., min_impressions: _Optional[int] = ..., min_impressions_new_variant: _Optional[int] = ..., confidence_level: _Optional[float] = ...) -> None: ...

class TrafficAllocationConfig(_message.Message):
    __slots__ = ()
    class WeightedSplitsEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: float
        def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    MODE_FIELD_NUMBER: _ClassVar[int]
    WEIGHTED_SPLITS_FIELD_NUMBER: _ClassVar[int]
    RAMP_SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    HOLDOUT_PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    MIN_TEST_DURATION_HOURS_FIELD_NUMBER: _ClassVar[int]
    MAX_TEST_DURATION_HOURS_FIELD_NUMBER: _ClassVar[int]
    mode: str
    weighted_splits: _containers.ScalarMap[str, float]
    ramp_schedule: _containers.RepeatedCompositeFieldContainer[TrafficRampStep]
    holdout_percentage: float
    min_test_duration_hours: int
    max_test_duration_hours: int
    def __init__(self, mode: _Optional[str] = ..., weighted_splits: _Optional[_Mapping[str, float]] = ..., ramp_schedule: _Optional[_Iterable[_Union[TrafficRampStep, _Mapping]]] = ..., holdout_percentage: _Optional[float] = ..., min_test_duration_hours: _Optional[int] = ..., max_test_duration_hours: _Optional[int] = ...) -> None: ...

class TrafficRampStep(_message.Message):
    __slots__ = ()
    STEP_NUMBER_FIELD_NUMBER: _ClassVar[int]
    TRAFFIC_PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    DURATION_HOURS_FIELD_NUMBER: _ClassVar[int]
    GATE_FIELD_NUMBER: _ClassVar[int]
    step_number: int
    traffic_percentage: float
    duration_hours: int
    gate: PerformanceGate
    def __init__(self, step_number: _Optional[int] = ..., traffic_percentage: _Optional[float] = ..., duration_hours: _Optional[int] = ..., gate: _Optional[_Union[PerformanceGate, _Mapping]] = ...) -> None: ...

class PerformanceGate(_message.Message):
    __slots__ = ()
    MIN_SUCCESS_RATE_FIELD_NUMBER: _ClassVar[int]
    MAX_AVG_DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    MAX_AVG_COST_FIELD_NUMBER: _ClassVar[int]
    MIN_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    MIN_SAMPLE_SIZE_FIELD_NUMBER: _ClassVar[int]
    min_success_rate: float
    max_avg_duration_ms: int
    max_avg_cost: float
    min_quality_score: float
    min_sample_size: int
    def __init__(self, min_success_rate: _Optional[float] = ..., max_avg_duration_ms: _Optional[int] = ..., max_avg_cost: _Optional[float] = ..., min_quality_score: _Optional[float] = ..., min_sample_size: _Optional[int] = ...) -> None: ...

class PerformanceThresholds(_message.Message):
    __slots__ = ()
    MIN_SUCCESS_RATE_FIELD_NUMBER: _ClassVar[int]
    MAX_AVG_COST_FIELD_NUMBER: _ClassVar[int]
    MIN_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    MAX_AVG_DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    RELATIVE_PERFORMANCE_GAP_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    MIN_SAMPLE_SIZE_FIELD_NUMBER: _ClassVar[int]
    MIN_AGE_HOURS_FIELD_NUMBER: _ClassVar[int]
    min_success_rate: float
    max_avg_cost: float
    min_quality_score: float
    max_avg_duration_ms: int
    relative_performance_gap: float
    confidence_level: float
    min_sample_size: int
    min_age_hours: int
    def __init__(self, min_success_rate: _Optional[float] = ..., max_avg_cost: _Optional[float] = ..., min_quality_score: _Optional[float] = ..., max_avg_duration_ms: _Optional[int] = ..., relative_performance_gap: _Optional[float] = ..., confidence_level: _Optional[float] = ..., min_sample_size: _Optional[int] = ..., min_age_hours: _Optional[int] = ...) -> None: ...

class AutoPromotionConfig(_message.Message):
    __slots__ = ()
    MIN_SUCCESS_RATE_FIELD_NUMBER: _ClassVar[int]
    MIN_IMPROVEMENT_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    MIN_SAMPLE_SIZE_FIELD_NUMBER: _ClassVar[int]
    MIN_TEST_DURATION_HOURS_FIELD_NUMBER: _ClassVar[int]
    MIN_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    MAX_AVG_COST_FIELD_NUMBER: _ClassVar[int]
    OLD_ACTIVE_STRATEGY_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_MANUAL_APPROVAL_FIELD_NUMBER: _ClassVar[int]
    min_success_rate: float
    min_improvement: float
    confidence_level: float
    min_sample_size: int
    min_test_duration_hours: int
    min_quality_score: float
    max_avg_cost: float
    old_active_strategy: str
    require_manual_approval: bool
    def __init__(self, min_success_rate: _Optional[float] = ..., min_improvement: _Optional[float] = ..., confidence_level: _Optional[float] = ..., min_sample_size: _Optional[int] = ..., min_test_duration_hours: _Optional[int] = ..., min_quality_score: _Optional[float] = ..., max_avg_cost: _Optional[float] = ..., old_active_strategy: _Optional[str] = ..., require_manual_approval: _Optional[bool] = ...) -> None: ...

class PromotionProposal(_message.Message):
    __slots__ = ()
    PROPOSAL_ID_FIELD_NUMBER: _ClassVar[int]
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
    JUSTIFICATION_FIELD_NUMBER: _ClassVar[int]
    METRICS_FIELD_NUMBER: _ClassVar[int]
    COMPARISON_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DECIDED_BY_FIELD_NUMBER: _ClassVar[int]
    DECIDED_AT_FIELD_NUMBER: _ClassVar[int]
    REJECTION_REASON_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    proposal_id: str
    variant_id: str
    activity_id: str
    justification: str
    metrics: PromotionMetricsSnapshot
    comparison: StatisticalComparison
    status: str
    decided_by: str
    decided_at: _timestamp_pb2.Timestamp
    rejection_reason: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, proposal_id: _Optional[str] = ..., variant_id: _Optional[str] = ..., activity_id: _Optional[str] = ..., justification: _Optional[str] = ..., metrics: _Optional[_Union[PromotionMetricsSnapshot, _Mapping]] = ..., comparison: _Optional[_Union[StatisticalComparison, _Mapping]] = ..., status: _Optional[str] = ..., decided_by: _Optional[str] = ..., decided_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., rejection_reason: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class PromotionMetricsSnapshot(_message.Message):
    __slots__ = ()
    TESTING_VARIANT_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_VARIANT_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_RATE_IMPROVEMENT_FIELD_NUMBER: _ClassVar[int]
    COST_REDUCTION_FIELD_NUMBER: _ClassVar[int]
    QUALITY_SCORE_IMPROVEMENT_FIELD_NUMBER: _ClassVar[int]
    testing_variant: VariantMetricsSummary
    active_variant: VariantMetricsSummary
    success_rate_improvement: float
    cost_reduction: float
    quality_score_improvement: float
    def __init__(self, testing_variant: _Optional[_Union[VariantMetricsSummary, _Mapping]] = ..., active_variant: _Optional[_Union[VariantMetricsSummary, _Mapping]] = ..., success_rate_improvement: _Optional[float] = ..., cost_reduction: _Optional[float] = ..., quality_score_improvement: _Optional[float] = ...) -> None: ...

class VariantMetricsSummary(_message.Message):
    __slots__ = ()
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_EXECUTIONS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_RATE_FIELD_NUMBER: _ClassVar[int]
    AVG_COST_FIELD_NUMBER: _ClassVar[int]
    AVG_DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    AVG_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    total_executions: int
    success_rate: float
    avg_cost: float
    avg_duration_ms: float
    avg_quality_score: float
    def __init__(self, variant_id: _Optional[str] = ..., total_executions: _Optional[int] = ..., success_rate: _Optional[float] = ..., avg_cost: _Optional[float] = ..., avg_duration_ms: _Optional[float] = ..., avg_quality_score: _Optional[float] = ...) -> None: ...

class StatisticalComparison(_message.Message):
    __slots__ = ()
    VARIANT_A_ID_FIELD_NUMBER: _ClassVar[int]
    VARIANT_B_ID_FIELD_NUMBER: _ClassVar[int]
    P_VALUE_FIELD_NUMBER: _ClassVar[int]
    IS_SIGNIFICANT_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    PROBABILITY_B_BETTER_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_LIFT_FIELD_NUMBER: _ClassVar[int]
    variant_a_id: str
    variant_b_id: str
    p_value: float
    is_significant: bool
    confidence_level: float
    probability_b_better: float
    expected_lift: float
    def __init__(self, variant_a_id: _Optional[str] = ..., variant_b_id: _Optional[str] = ..., p_value: _Optional[float] = ..., is_significant: _Optional[bool] = ..., confidence_level: _Optional[float] = ..., probability_b_better: _Optional[float] = ..., expected_lift: _Optional[float] = ...) -> None: ...
