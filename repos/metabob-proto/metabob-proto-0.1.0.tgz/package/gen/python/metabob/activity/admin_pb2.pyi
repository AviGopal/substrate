import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DeploymentStrategy(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DEPLOYMENT_STRATEGY_UNSPECIFIED: _ClassVar[DeploymentStrategy]
    DEPLOYMENT_STRATEGY_IMMEDIATE: _ClassVar[DeploymentStrategy]
    DEPLOYMENT_STRATEGY_GRADUAL: _ClassVar[DeploymentStrategy]
    DEPLOYMENT_STRATEGY_CANARY: _ClassVar[DeploymentStrategy]
    DEPLOYMENT_STRATEGY_MANUAL_APPROVAL: _ClassVar[DeploymentStrategy]
DEPLOYMENT_STRATEGY_UNSPECIFIED: DeploymentStrategy
DEPLOYMENT_STRATEGY_IMMEDIATE: DeploymentStrategy
DEPLOYMENT_STRATEGY_GRADUAL: DeploymentStrategy
DEPLOYMENT_STRATEGY_CANARY: DeploymentStrategy
DEPLOYMENT_STRATEGY_MANUAL_APPROVAL: DeploymentStrategy

class AdminConfig(_message.Message):
    __slots__ = ()
    AUTHORING_FIELD_NUMBER: _ClassVar[int]
    VALIDATION_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    DEPLOYMENT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_BY_FIELD_NUMBER: _ClassVar[int]
    authoring: AuthoringMetadata
    validation: ValidationRules
    documentation: DocumentationMetadata
    deployment: DeploymentConfig
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    updated_by: str
    def __init__(self, authoring: _Optional[_Union[AuthoringMetadata, _Mapping]] = ..., validation: _Optional[_Union[ValidationRules, _Mapping]] = ..., documentation: _Optional[_Union[DocumentationMetadata, _Mapping]] = ..., deployment: _Optional[_Union[DeploymentConfig, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_by: _Optional[str] = ...) -> None: ...

class AuthoringMetadata(_message.Message):
    __slots__ = ()
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    CONTRIBUTORS_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    MATURITY_FIELD_NUMBER: _ClassVar[int]
    LICENSE_FIELD_NUMBER: _ClassVar[int]
    COPYRIGHT_HOLDER_FIELD_NUMBER: _ClassVar[int]
    COPYRIGHT_YEAR_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_FIELD_NUMBER: _ClassVar[int]
    ISSUE_TRACKER_FIELD_NUMBER: _ClassVar[int]
    DOCUMENTATION_URL_FIELD_NUMBER: _ClassVar[int]
    CONTACT_EMAIL_FIELD_NUMBER: _ClassVar[int]
    SLACK_CHANNEL_FIELD_NUMBER: _ClassVar[int]
    author: str
    contributors: _containers.RepeatedScalarFieldContainer[str]
    organization: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    category: str
    maturity: str
    license: str
    copyright_holder: str
    copyright_year: int
    repository: str
    issue_tracker: str
    documentation_url: str
    contact_email: str
    slack_channel: str
    def __init__(self, author: _Optional[str] = ..., contributors: _Optional[_Iterable[str]] = ..., organization: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., category: _Optional[str] = ..., maturity: _Optional[str] = ..., license: _Optional[str] = ..., copyright_holder: _Optional[str] = ..., copyright_year: _Optional[int] = ..., repository: _Optional[str] = ..., issue_tracker: _Optional[str] = ..., documentation_url: _Optional[str] = ..., contact_email: _Optional[str] = ..., slack_channel: _Optional[str] = ...) -> None: ...

class ValidationRules(_message.Message):
    __slots__ = ()
    REQUIRED_FIELDS_FIELD_NUMBER: _ClassVar[int]
    MIN_TASK_STEPS_FIELD_NUMBER: _ClassVar[int]
    MAX_TASK_STEPS_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_VALIDATION_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_DOCUMENTATION_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_EXAMPLES_FIELD_NUMBER: _ClassVar[int]
    FORBIDDEN_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    MIN_DESCRIPTION_LENGTH_FIELD_NUMBER: _ClassVar[int]
    MIN_PROMPT_LENGTH_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_COMMANDS_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPENDENCY_DEPTH_FIELD_NUMBER: _ClassVar[int]
    MAX_FILE_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_TOTAL_PROMPT_LENGTH_FIELD_NUMBER: _ClassVar[int]
    required_fields: _containers.RepeatedScalarFieldContainer[str]
    min_task_steps: int
    max_task_steps: int
    require_validation: bool
    require_documentation: bool
    require_examples: bool
    forbidden_patterns: _containers.RepeatedScalarFieldContainer[str]
    required_patterns: _containers.RepeatedScalarFieldContainer[str]
    min_description_length: int
    min_prompt_length: int
    custom_commands: _containers.RepeatedCompositeFieldContainer[TemplateValidationCommand]
    max_dependency_depth: int
    max_file_size_bytes: int
    max_total_prompt_length: int
    def __init__(self, required_fields: _Optional[_Iterable[str]] = ..., min_task_steps: _Optional[int] = ..., max_task_steps: _Optional[int] = ..., require_validation: _Optional[bool] = ..., require_documentation: _Optional[bool] = ..., require_examples: _Optional[bool] = ..., forbidden_patterns: _Optional[_Iterable[str]] = ..., required_patterns: _Optional[_Iterable[str]] = ..., min_description_length: _Optional[int] = ..., min_prompt_length: _Optional[int] = ..., custom_commands: _Optional[_Iterable[_Union[TemplateValidationCommand, _Mapping]]] = ..., max_dependency_depth: _Optional[int] = ..., max_file_size_bytes: _Optional[int] = ..., max_total_prompt_length: _Optional[int] = ...) -> None: ...

class TemplateValidationCommand(_message.Message):
    __slots__ = ()
    NAME_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_EXIT_CODE_FIELD_NUMBER: _ClassVar[int]
    WORKING_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    name: str
    command: str
    required: bool
    timeout_seconds: int
    description: str
    expected_exit_code: int
    working_directory: str
    def __init__(self, name: _Optional[str] = ..., command: _Optional[str] = ..., required: _Optional[bool] = ..., timeout_seconds: _Optional[int] = ..., description: _Optional[str] = ..., expected_exit_code: _Optional[int] = ..., working_directory: _Optional[str] = ...) -> None: ...

class DocumentationMetadata(_message.Message):
    __slots__ = ()
    EXAMPLES_FIELD_NUMBER: _ClassVar[int]
    FAILURE_MODES_FIELD_NUMBER: _ClassVar[int]
    BEST_PRACTICES_FIELD_NUMBER: _ClassVar[int]
    LIMITATIONS_FIELD_NUMBER: _ClassVar[int]
    PREREQUISITES_FIELD_NUMBER: _ClassVar[int]
    RELATED_TEMPLATES_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_REFERENCES_FIELD_NUMBER: _ClassVar[int]
    CHANGELOG_FIELD_NUMBER: _ClassVar[int]
    examples: _containers.RepeatedCompositeFieldContainer[UsageExample]
    failure_modes: _containers.RepeatedCompositeFieldContainer[FailureMode]
    best_practices: _containers.RepeatedScalarFieldContainer[str]
    limitations: _containers.RepeatedScalarFieldContainer[str]
    prerequisites: _containers.RepeatedScalarFieldContainer[str]
    related_templates: _containers.RepeatedScalarFieldContainer[str]
    external_references: _containers.RepeatedScalarFieldContainer[str]
    changelog: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, examples: _Optional[_Iterable[_Union[UsageExample, _Mapping]]] = ..., failure_modes: _Optional[_Iterable[_Union[FailureMode, _Mapping]]] = ..., best_practices: _Optional[_Iterable[str]] = ..., limitations: _Optional[_Iterable[str]] = ..., prerequisites: _Optional[_Iterable[str]] = ..., related_templates: _Optional[_Iterable[str]] = ..., external_references: _Optional[_Iterable[str]] = ..., changelog: _Optional[_Iterable[str]] = ...) -> None: ...

class UsageExample(_message.Message):
    __slots__ = ()
    class VariablesEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    VARIABLES_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_OUTCOME_FIELD_NUMBER: _ClassVar[int]
    DIFFICULTY_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_DURATION_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    variables: _containers.ScalarMap[str, str]
    expected_outcome: str
    difficulty: str
    estimated_duration: str
    notes: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., variables: _Optional[_Mapping[str, str]] = ..., expected_outcome: _Optional[str] = ..., difficulty: _Optional[str] = ..., estimated_duration: _Optional[str] = ..., notes: _Optional[str] = ...) -> None: ...

class FailureMode(_message.Message):
    __slots__ = ()
    SCENARIO_FIELD_NUMBER: _ClassVar[int]
    SYMPTOM_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    PREVENTION_GUIDE_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    ERROR_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    scenario: str
    symptom: str
    resolution: str
    prevention_guide: str
    frequency: str
    severity: str
    error_patterns: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, scenario: _Optional[str] = ..., symptom: _Optional[str] = ..., resolution: _Optional[str] = ..., prevention_guide: _Optional[str] = ..., frequency: _Optional[str] = ..., severity: _Optional[str] = ..., error_patterns: _Optional[_Iterable[str]] = ...) -> None: ...

class DeploymentConfig(_message.Message):
    __slots__ = ()
    STRATEGY_FIELD_NUMBER: _ClassVar[int]
    INITIAL_TRAFFIC_PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    TRAFFIC_INCREMENT_FIELD_NUMBER: _ClassVar[int]
    STAGE_DURATION_HOURS_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_FIELD_NUMBER: _ClassVar[int]
    NOTIFICATIONS_FIELD_NUMBER: _ClassVar[int]
    APPROVAL_REQUIRED_FIELD_NUMBER: _ClassVar[int]
    APPROVERS_FIELD_NUMBER: _ClassVar[int]
    MIN_APPROVALS_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_DAYS_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_HOURS_UTC_FIELD_NUMBER: _ClassVar[int]
    LAST_DEPLOYED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_DEPLOYED_BY_FIELD_NUMBER: _ClassVar[int]
    strategy: DeploymentStrategy
    initial_traffic_percentage: float
    traffic_increment: float
    stage_duration_hours: int
    rollback: RollbackConfig
    notifications: NotificationConfig
    approval_required: bool
    approvers: _containers.RepeatedScalarFieldContainer[str]
    min_approvals: int
    allowed_days: _containers.RepeatedScalarFieldContainer[str]
    allowed_hours_utc: DeploymentWindow
    last_deployed_at: _timestamp_pb2.Timestamp
    last_deployed_by: str
    def __init__(self, strategy: _Optional[_Union[DeploymentStrategy, str]] = ..., initial_traffic_percentage: _Optional[float] = ..., traffic_increment: _Optional[float] = ..., stage_duration_hours: _Optional[int] = ..., rollback: _Optional[_Union[RollbackConfig, _Mapping]] = ..., notifications: _Optional[_Union[NotificationConfig, _Mapping]] = ..., approval_required: _Optional[bool] = ..., approvers: _Optional[_Iterable[str]] = ..., min_approvals: _Optional[int] = ..., allowed_days: _Optional[_Iterable[str]] = ..., allowed_hours_utc: _Optional[_Union[DeploymentWindow, _Mapping]] = ..., last_deployed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_deployed_by: _Optional[str] = ...) -> None: ...

class DeploymentWindow(_message.Message):
    __slots__ = ()
    START_HOUR_FIELD_NUMBER: _ClassVar[int]
    END_HOUR_FIELD_NUMBER: _ClassVar[int]
    start_hour: int
    end_hour: int
    def __init__(self, start_hour: _Optional[int] = ..., end_hour: _Optional[int] = ...) -> None: ...

class RollbackConfig(_message.Message):
    __slots__ = ()
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_ON_FAILURE_RATE_FIELD_NUMBER: _ClassVar[int]
    MIN_EXECUTIONS_BEFORE_ROLLBACK_FIELD_NUMBER: _ClassVar[int]
    AUTOMATIC_ROLLBACK_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_ON_ROLLBACK_FIELD_NUMBER: _ClassVar[int]
    ROLLBACK_TO_VERSION_FIELD_NUMBER: _ClassVar[int]
    TARGET_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    PRESERVE_METRICS_FIELD_NUMBER: _ClassVar[int]
    MAX_WAIT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    trigger_on_failure_rate: float
    min_executions_before_rollback: int
    automatic_rollback: bool
    notify_on_rollback: bool
    rollback_to_version: str
    target_version_id: str
    preserve_metrics: bool
    max_wait_seconds: int
    def __init__(self, enabled: _Optional[bool] = ..., trigger_on_failure_rate: _Optional[float] = ..., min_executions_before_rollback: _Optional[int] = ..., automatic_rollback: _Optional[bool] = ..., notify_on_rollback: _Optional[bool] = ..., rollback_to_version: _Optional[str] = ..., target_version_id: _Optional[str] = ..., preserve_metrics: _Optional[bool] = ..., max_wait_seconds: _Optional[int] = ...) -> None: ...

class NotificationConfig(_message.Message):
    __slots__ = ()
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    CHANNELS_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_METRICS_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_ERROR_DETAILS_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_ON_SUCCESS_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_ON_FAILURE_FIELD_NUMBER: _ClassVar[int]
    MIN_SEVERITY_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    channels: _containers.RepeatedScalarFieldContainer[str]
    events: _containers.RepeatedScalarFieldContainer[str]
    include_metrics: bool
    include_error_details: bool
    notify_on_success: bool
    notify_on_failure: bool
    min_severity: str
    message_template: str
    def __init__(self, enabled: _Optional[bool] = ..., channels: _Optional[_Iterable[str]] = ..., events: _Optional[_Iterable[str]] = ..., include_metrics: _Optional[bool] = ..., include_error_details: _Optional[bool] = ..., notify_on_success: _Optional[bool] = ..., notify_on_failure: _Optional[bool] = ..., min_severity: _Optional[str] = ..., message_template: _Optional[str] = ...) -> None: ...
