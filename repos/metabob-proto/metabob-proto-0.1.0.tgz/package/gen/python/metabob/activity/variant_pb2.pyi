import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from metabob.common import types_pb2 as _types_pb2
from metabob.activity import execution_pb2 as _execution_pb2
from metabob.activity import optimization_pb2 as _optimization_pb2
from metabob.activity import admin_pb2 as _admin_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TaskStep(_message.Message):
    __slots__ = ()
    ID_FIELD_NUMBER: _ClassVar[int]
    SUBAGENT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DEPENDENCIES_FIELD_NUMBER: _ClassVar[int]
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    VALIDATION_FIELD_NUMBER: _ClassVar[int]
    RETRY_FIELD_NUMBER: _ClassVar[int]
    METRICS_FIELD_NUMBER: _ClassVar[int]
    GUIDANCE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_ACTIONS_FIELD_NUMBER: _ClassVar[int]
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    COMPLEXITY_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_CONFIG_FIELD_NUMBER: _ClassVar[int]
    IMPULSE_REFS_FIELD_NUMBER: _ClassVar[int]
    id: str
    subagent: str
    description: str
    dependencies: _containers.RepeatedScalarFieldContainer[str]
    prompt: TaskPrompt
    validation: TaskValidation
    retry: TaskRetry
    metrics: TaskMetrics
    guidance: _containers.RepeatedScalarFieldContainer[str]
    expected_actions: _containers.RepeatedScalarFieldContainer[str]
    tools: _execution_pb2.TaskTools
    complexity: TaskComplexity
    execution_config: _execution_pb2.TaskExecutionConfig
    impulse_refs: _containers.RepeatedCompositeFieldContainer[_execution_pb2.ImpulseReference]
    def __init__(self, id: _Optional[str] = ..., subagent: _Optional[str] = ..., description: _Optional[str] = ..., dependencies: _Optional[_Iterable[str]] = ..., prompt: _Optional[_Union[TaskPrompt, _Mapping]] = ..., validation: _Optional[_Union[TaskValidation, _Mapping]] = ..., retry: _Optional[_Union[TaskRetry, _Mapping]] = ..., metrics: _Optional[_Union[TaskMetrics, _Mapping]] = ..., guidance: _Optional[_Iterable[str]] = ..., expected_actions: _Optional[_Iterable[str]] = ..., tools: _Optional[_Union[_execution_pb2.TaskTools, _Mapping]] = ..., complexity: _Optional[_Union[TaskComplexity, _Mapping]] = ..., execution_config: _Optional[_Union[_execution_pb2.TaskExecutionConfig, _Mapping]] = ..., impulse_refs: _Optional[_Iterable[_Union[_execution_pb2.ImpulseReference, _Mapping]]] = ...) -> None: ...

class TaskPrompt(_message.Message):
    __slots__ = ()
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    MAX_TOKENS_FIELD_NUMBER: _ClassVar[int]
    COMPRESSION_STRATEGY_FIELD_NUMBER: _ClassVar[int]
    VARIABLES_FIELD_NUMBER: _ClassVar[int]
    template: str
    max_tokens: int
    compression_strategy: str
    variables: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, template: _Optional[str] = ..., max_tokens: _Optional[int] = ..., compression_strategy: _Optional[str] = ..., variables: _Optional[_Iterable[str]] = ...) -> None: ...

class TaskValidation(_message.Message):
    __slots__ = ()
    REQUIRED_FILES_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    FORBIDDEN_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    required_files: _containers.RepeatedScalarFieldContainer[str]
    required_patterns: _containers.RepeatedScalarFieldContainer[str]
    forbidden_patterns: _containers.RepeatedScalarFieldContainer[str]
    commands: _containers.RepeatedCompositeFieldContainer[_execution_pb2.ValidationCommand]
    def __init__(self, required_files: _Optional[_Iterable[str]] = ..., required_patterns: _Optional[_Iterable[str]] = ..., forbidden_patterns: _Optional[_Iterable[str]] = ..., commands: _Optional[_Iterable[_Union[_execution_pb2.ValidationCommand, _Mapping]]] = ...) -> None: ...

class TaskRetry(_message.Message):
    __slots__ = ()
    MAX_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    STRATEGY_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_PROMPT_FIELD_NUMBER: _ClassVar[int]
    max_attempts: int
    strategy: str
    fallback_prompt: str
    def __init__(self, max_attempts: _Optional[int] = ..., strategy: _Optional[str] = ..., fallback_prompt: _Optional[str] = ...) -> None: ...

class TaskMetrics(_message.Message):
    __slots__ = ()
    SUCCESS_RATE_FIELD_NUMBER: _ClassVar[int]
    AVG_TOKENS_FIELD_NUMBER: _ClassVar[int]
    AVG_DURATION_FIELD_NUMBER: _ClassVar[int]
    COMMON_FAILURES_FIELD_NUMBER: _ClassVar[int]
    success_rate: float
    avg_tokens: int
    avg_duration: int
    common_failures: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, success_rate: _Optional[float] = ..., avg_tokens: _Optional[int] = ..., avg_duration: _Optional[int] = ..., common_failures: _Optional[_Iterable[str]] = ...) -> None: ...

class TaskComplexity(_message.Message):
    __slots__ = ()
    TIER_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_TOKENS_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_REASONING_FIELD_NUMBER: _ClassVar[int]
    MIN_MODEL_CAPABILITY_FIELD_NUMBER: _ClassVar[int]
    tier: str
    estimated_tokens: int
    requires_reasoning: bool
    min_model_capability: str
    def __init__(self, tier: _Optional[str] = ..., estimated_tokens: _Optional[int] = ..., requires_reasoning: _Optional[bool] = ..., min_model_capability: _Optional[str] = ...) -> None: ...

class ActivityVariant(_message.Message):
    __slots__ = ()
    class VariablesEntry(_message.Message):
        __slots__ = ()
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
    VARIANT_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    GENEALOGY_FIELD_NUMBER: _ClassVar[int]
    TASK_STEPS_FIELD_NUMBER: _ClassVar[int]
    VARIABLES_FIELD_NUMBER: _ClassVar[int]
    PROMPT_STRATEGY_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_BUDGET_TOKENS_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_COST_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_CONFIG_FIELD_NUMBER: _ClassVar[int]
    OPTIMIZATION_CONFIG_FIELD_NUMBER: _ClassVar[int]
    ADMIN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    COMPOSITION_FIELD_NUMBER: _ClassVar[int]
    LEARNING_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_OUTCOMES_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    activity_id: str
    variant_name: str
    description: str
    version: int
    genealogy: _types_pb2.Genealogy
    task_steps: _containers.RepeatedCompositeFieldContainer[TaskStep]
    variables: _containers.ScalarMap[str, str]
    prompt_strategy: str
    context_budget_tokens: int
    expected_duration_ms: int
    expected_cost: float
    expected_quality_score: float
    status: _types_pb2.EntityStatus
    created_at: _timestamp_pb2.Timestamp
    execution_config: _execution_pb2.ExecutionConfig
    optimization_config: _optimization_pb2.OptimizationConfig
    admin_config: _admin_pb2.AdminConfig
    composition: CompositionConfig
    learning: LearningConfig
    expected_outcomes: _containers.RepeatedCompositeFieldContainer[ExpectedOutcome]
    def __init__(self, variant_id: _Optional[str] = ..., activity_id: _Optional[str] = ..., variant_name: _Optional[str] = ..., description: _Optional[str] = ..., version: _Optional[int] = ..., genealogy: _Optional[_Union[_types_pb2.Genealogy, _Mapping]] = ..., task_steps: _Optional[_Iterable[_Union[TaskStep, _Mapping]]] = ..., variables: _Optional[_Mapping[str, str]] = ..., prompt_strategy: _Optional[str] = ..., context_budget_tokens: _Optional[int] = ..., expected_duration_ms: _Optional[int] = ..., expected_cost: _Optional[float] = ..., expected_quality_score: _Optional[float] = ..., status: _Optional[_Union[_types_pb2.EntityStatus, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., execution_config: _Optional[_Union[_execution_pb2.ExecutionConfig, _Mapping]] = ..., optimization_config: _Optional[_Union[_optimization_pb2.OptimizationConfig, _Mapping]] = ..., admin_config: _Optional[_Union[_admin_pb2.AdminConfig, _Mapping]] = ..., composition: _Optional[_Union[CompositionConfig, _Mapping]] = ..., learning: _Optional[_Union[LearningConfig, _Mapping]] = ..., expected_outcomes: _Optional[_Iterable[_Union[ExpectedOutcome, _Mapping]]] = ...) -> None: ...

class VariantPerformanceMetrics(_message.Message):
    __slots__ = ()
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
    TOTAL_IMPRESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SELECTIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_CONVERSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SUCCESSES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FAILURES_FIELD_NUMBER: _ClassVar[int]
    AVG_DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    AVG_COST_FIELD_NUMBER: _ClassVar[int]
    AVG_QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_RATE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_VALUE_FIELD_NUMBER: _ClassVar[int]
    THOMPSON_ALPHA_FIELD_NUMBER: _ClassVar[int]
    THOMPSON_BETA_FIELD_NUMBER: _ClassVar[int]
    LAST_UPDATED_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    activity_id: str
    total_impressions: int
    total_selections: int
    total_conversions: int
    total_successes: int
    total_failures: int
    avg_duration_ms: float
    avg_cost: float
    avg_quality_score: float
    conversion_rate: float
    expected_value: float
    thompson_alpha: float
    thompson_beta: float
    last_updated: _timestamp_pb2.Timestamp
    def __init__(self, variant_id: _Optional[str] = ..., activity_id: _Optional[str] = ..., total_impressions: _Optional[int] = ..., total_selections: _Optional[int] = ..., total_conversions: _Optional[int] = ..., total_successes: _Optional[int] = ..., total_failures: _Optional[int] = ..., avg_duration_ms: _Optional[float] = ..., avg_cost: _Optional[float] = ..., avg_quality_score: _Optional[float] = ..., conversion_rate: _Optional[float] = ..., expected_value: _Optional[float] = ..., thompson_alpha: _Optional[float] = ..., thompson_beta: _Optional[float] = ..., last_updated: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CompositionConfig(_message.Message):
    __slots__ = ()
    STANDALONE_FIELD_NUMBER: _ClassVar[int]
    COMPOSES_WITH_FIELD_NUMBER: _ClassVar[int]
    EXAMPLES_FIELD_NUMBER: _ClassVar[int]
    IS_SUBACTIVITY_FIELD_NUMBER: _ClassVar[int]
    PARENT_ACTIVITIES_FIELD_NUMBER: _ClassVar[int]
    standalone: bool
    composes_with: _containers.RepeatedScalarFieldContainer[str]
    examples: _containers.RepeatedScalarFieldContainer[str]
    is_subactivity: bool
    parent_activities: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, standalone: _Optional[bool] = ..., composes_with: _Optional[_Iterable[str]] = ..., examples: _Optional[_Iterable[str]] = ..., is_subactivity: _Optional[bool] = ..., parent_activities: _Optional[_Iterable[str]] = ...) -> None: ...

class LearningConfig(_message.Message):
    __slots__ = ()
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_POINTS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_TRANSCRIPT_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_TOOL_USAGE_FIELD_NUMBER: _ClassVar[int]
    MIN_CONFIDENCE_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    feedback_points: _containers.RepeatedScalarFieldContainer[str]
    success_patterns: _containers.RepeatedScalarFieldContainer[str]
    failure_patterns: _containers.RepeatedScalarFieldContainer[str]
    capture_transcript: bool
    capture_tool_usage: bool
    min_confidence_threshold: float
    def __init__(self, enabled: _Optional[bool] = ..., feedback_points: _Optional[_Iterable[str]] = ..., success_patterns: _Optional[_Iterable[str]] = ..., failure_patterns: _Optional[_Iterable[str]] = ..., capture_transcript: _Optional[bool] = ..., capture_tool_usage: _Optional[bool] = ..., min_confidence_threshold: _Optional[float] = ...) -> None: ...

class ExpectedOutcome(_message.Message):
    __slots__ = ()
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    VERIFICATION_METHOD_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    VERIFICATION_COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FILES_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    description: str
    verification_method: str
    success_criteria: _containers.RepeatedScalarFieldContainer[str]
    verification_command: str
    expected_files: _containers.RepeatedScalarFieldContainer[str]
    required: bool
    weight: float
    def __init__(self, description: _Optional[str] = ..., verification_method: _Optional[str] = ..., success_criteria: _Optional[_Iterable[str]] = ..., verification_command: _Optional[str] = ..., expected_files: _Optional[_Iterable[str]] = ..., required: _Optional[bool] = ..., weight: _Optional[float] = ...) -> None: ...
