import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EntityStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENTITY_STATUS_UNSPECIFIED: _ClassVar[EntityStatus]
    ENTITY_STATUS_DRAFT: _ClassVar[EntityStatus]
    ENTITY_STATUS_TESTING: _ClassVar[EntityStatus]
    ENTITY_STATUS_ACTIVE: _ClassVar[EntityStatus]
    ENTITY_STATUS_DEPRECATED: _ClassVar[EntityStatus]

class EvolutionType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVOLUTION_TYPE_UNSPECIFIED: _ClassVar[EvolutionType]
    EVOLUTION_TYPE_ROOT: _ClassVar[EvolutionType]
    EVOLUTION_TYPE_DERIVED: _ClassVar[EvolutionType]
    EVOLUTION_TYPE_MERGED: _ClassVar[EvolutionType]
    EVOLUTION_TYPE_REFINED: _ClassVar[EvolutionType]
    EVOLUTION_TYPE_SPLIT: _ClassVar[EvolutionType]

class ActivityCategory(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTIVITY_CATEGORY_UNSPECIFIED: _ClassVar[ActivityCategory]
    ACTIVITY_CATEGORY_FEATURE: _ClassVar[ActivityCategory]
    ACTIVITY_CATEGORY_BUGFIX: _ClassVar[ActivityCategory]
    ACTIVITY_CATEGORY_REFACTOR: _ClassVar[ActivityCategory]
    ACTIVITY_CATEGORY_TOOL: _ClassVar[ActivityCategory]
    ACTIVITY_CATEGORY_META: _ClassVar[ActivityCategory]
ENTITY_STATUS_UNSPECIFIED: EntityStatus
ENTITY_STATUS_DRAFT: EntityStatus
ENTITY_STATUS_TESTING: EntityStatus
ENTITY_STATUS_ACTIVE: EntityStatus
ENTITY_STATUS_DEPRECATED: EntityStatus
EVOLUTION_TYPE_UNSPECIFIED: EvolutionType
EVOLUTION_TYPE_ROOT: EvolutionType
EVOLUTION_TYPE_DERIVED: EvolutionType
EVOLUTION_TYPE_MERGED: EvolutionType
EVOLUTION_TYPE_REFINED: EvolutionType
EVOLUTION_TYPE_SPLIT: EvolutionType
ACTIVITY_CATEGORY_UNSPECIFIED: ActivityCategory
ACTIVITY_CATEGORY_FEATURE: ActivityCategory
ACTIVITY_CATEGORY_BUGFIX: ActivityCategory
ACTIVITY_CATEGORY_REFACTOR: ActivityCategory
ACTIVITY_CATEGORY_TOOL: ActivityCategory
ACTIVITY_CATEGORY_META: ActivityCategory

class Genealogy(_message.Message):
    __slots__ = ()
    CONTENT_HASH_FIELD_NUMBER: _ClassVar[int]
    PARENT_HASH_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_FIELD_NUMBER: _ClassVar[int]
    EVOLUTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    EVOLUTION_NOTE_FIELD_NUMBER: _ClassVar[int]
    content_hash: str
    parent_hash: str
    lineage: _containers.RepeatedScalarFieldContainer[str]
    evolution_type: EvolutionType
    evolution_note: str
    def __init__(self, content_hash: _Optional[str] = ..., parent_hash: _Optional[str] = ..., lineage: _Optional[_Iterable[str]] = ..., evolution_type: _Optional[_Union[EvolutionType, str]] = ..., evolution_note: _Optional[str] = ...) -> None: ...

class Timestamps(_message.Message):
    __slots__ = ()
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TokenUsage(_message.Message):
    __slots__ = ()
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    CACHE_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    input_tokens: int
    output_tokens: int
    cache_tokens: int
    total_tokens: int
    def __init__(self, input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., cache_tokens: _Optional[int] = ..., total_tokens: _Optional[int] = ...) -> None: ...

class Cost(_message.Message):
    __slots__ = ()
    INPUT_COST_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_COST_FIELD_NUMBER: _ClassVar[int]
    CACHE_COST_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_FIELD_NUMBER: _ClassVar[int]
    input_cost: float
    output_cost: float
    cache_cost: float
    total_cost: float
    def __init__(self, input_cost: _Optional[float] = ..., output_cost: _Optional[float] = ..., cache_cost: _Optional[float] = ..., total_cost: _Optional[float] = ...) -> None: ...
