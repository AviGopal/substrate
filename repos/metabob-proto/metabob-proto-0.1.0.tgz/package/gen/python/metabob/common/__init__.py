"""Common protocol buffer types"""

from .types_pb2 import (
    Genealogy,
    EntityStatus,
)

__all__ = [
    "Genealogy",
    "EntityStatus",
]
